package com.laurynas.interview.model;

public enum PaymentType {
    TYPE1, TYPE2, TYPE3
}
